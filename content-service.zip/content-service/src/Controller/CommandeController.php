<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;

class CommandeController extends AbstractController
{
    #[Route('/commande/read', name: 'read_commande', methods: ['POST'])] 
    public function read(Request $request, EntityManagerInterface $entityManager): JsonResponse
    {  
        $data = json_decode($request->getContent(), true); 
        
        $commande = $entityManager->getRepository(commande::class)->find($data['id']); 
        
        if (!$commande) { 
            return new JsonResponse(['status' => 'Commande not found'], JsonResponse::HTTP_404);
        } 
        
        return new JsonResponse([ 
            'id' => $commande->getId(), 
            'title' => $commande->getTitle(), 
            'content' => $commande->getContent(), 
        ], JsonResponse::HTTP_OK); 
    }
    
    #[Route('/commande/update', name: 'update_commande', methods: ['POST'])] 
    public function update(Request $request, EntityManagerInterface $entityManager) : JsonResponse
    { 
        $data = json_decode($request->getContent(), true);
        $commande = $entityManager->getRepository(commande::class)->find($data['id']);
        
        if (!$commande) {
            return new JsonResponse(['status' => 'commande not found'], JsonResponse::HTTP_404);
        }
        
        $commande->setTitle($data['title']); 
        $commande->setContent($data['content']); 
        $entityManager->flush(); 
        
        return new JsonResponse(['status' => 'commande updated!'], JsonResponse::HTTP_ok);
    }

    
    #[Route('/commande/delete', name: 'delete_commande', methods: ['POST'])] 
    public function delete(Request $request, EntityManagerInterface $entityManager): JsonResponse
    { 
        $data = json_decode($request->getContent(), true); 
        $commande = $entityManager->getRepository(commande::class)->find($data['id']); 
        if (!$commande) { 
            return new JsonResponse(['status' => 'commande not found'], JsonResponse::HTTP_404);  
        } 
        
        $entityManager->remove($commande); 
        $entityManager->flush(); 
        return new JsonResponse(['status' => 'commande deleted!'], JsonResponse::HTTP_ok); 
    }

    
    $response = $this->client->request('POST', 'http://billing-service.local/create-in'){ 
        'json' => [ 
            'amount' => $data['total_price'], 
            'due_date' => (new \DateTime('+30 days'))->format('Y-m-d'), 
            'customer_email' => $data['customer_email'], 
        ];
    };
}
