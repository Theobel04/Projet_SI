<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use App\Entity\Notification;
use Doctrine\ORM\EntityManagerInterface;

class NotificationController extends AbstractController
{
    #[Route('/post', name: 'create_post', methods: ['POST'])] 
    public function create(Request $request, EntityManagerInterface $entityManager): JsonResponse 
    { 
        $data = json_decode($request->getContent(), true); 

        $post = new Post(); 
        $post->setTitle($data['title']); 
        $post->setContent($data['content']); 
    
        $entityManager->persist($post); 
        $entityManager->flush(); 
        
        return new JsonResponse(['status' => 'Post created!'], JsonResponse::HTTP_CREATED); }
    
}
