<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;

class BillingController extends AbstractController
{
    #[Route('/post/read', name: 'read_post', methods: ['POST'])] 
    public function read(Request $request, EntityManagerInterface $entityManager): JsonResponse
    {  
        $data = json_decode($request->getContent(), true); 
        
        $post = $entityManager->getRepository(Post::class)->find($data['id']); 
        
        if (!$post) { 
            return new JsonResponse(['status' => 'Post not found'], JsonResponse::HTTP_404);
        } 
        
        return new JsonResponse([ 
            'id' => $post->getId(), 
            'title' => $post->getTitle(), 
            'content' => $post->getContent(), 
        ], JsonResponse::HTTP_OK); 
    }
    
    #[Route('/post/update', name: 'update_post', methods: ['POST'])] 
    public function update(Request $request, EntityManagerInterface $entityManager) : JsonResponse
    { 
        $data = json_decode($request->getContent(), true);
        $post = $entityManager->getRepository(Post::class)->find($data['id']);
        
        if (!$post) {
            return new JsonResponse(['status' => 'Post not found'], JsonResponse::HTTP_404);
        }
        
        $post->setTitle($data['title']); 
        $post->setContent($data['content']); 
        $entityManager->flush(); 
        
        return new JsonResponse(['status' => 'Post updated!'], JsonResponse::HTTP_ok);
    }

    
    #[Route('/post/delete', name: 'delete_post', methods: ['POST'])] 
    public function delete(Request $request, EntityManagerInterface $entityManager): JsonResponse
    { 
        $data = json_decode($request->getContent(), true); 
        $post = $entityManager->getRepository(Post::class)->find($data['id']); 
        if (!$post) { 
            return new JsonResponse(['status' => 'Post not found'], JsonResponse::HTTP_404);  
        } 
        
        $entityManager->remove($post); 
        $entityManager->flush(); 
        return new JsonResponse(['status' => 'Post deleted!'], JsonResponse::HTTP_ok); 
    }

    $notificationResponse = $this->client->request('POST', 'http://notification-service') 
        'json' => [ 
            'sujet' => 'Billing', 
            'recipient' => $data['customer_email'], 
            'message' => 'Your invoice has been created.',
        ] 
}
